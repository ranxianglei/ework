// Single source of truth for ework-web + ework-daemon .env keys.
//
// Each key has:
//   - envVar:     the literal env var name written to .env
//   - generate(): returns the value to use when forward-filling a missing key
//   - secret?:    true if the value is sensitive (token, secret, password)
//                 — used to redact in `config list` output
//
// The forward-fill principle: when a user re-runs install and we preserve
// their existing .env, we walk this list and append any missing keys with
// freshly generated values. User-set values are NEVER overwritten.
//
// This schema MUST stay in sync with ework-web's src/config.ts (the runtime
// Zod parser). Any new required field added there must be added here too,
// otherwise stale .env files will crash the next start (the v0.1.17 bug).

import { randomBytes } from "node:crypto";
import type { PathConfig } from "./paths.ts";

export type EnvFile = "web" | "daemon" | "router";

export interface InstallContext {
  paths: PathConfig;
  workPort: number;
  daemonPort: number;
  routerPort: number;
  botName: string;
  operatorLogin: string;
  // opencode binary path (looked up via preflight)
  opencodeBin: string;
  piBin: string;
  piProvider: string;
  piModel: string;
}

export interface EnvKeySpec {
  envVar: string;
  file: EnvFile;
  secret?: boolean;
  generate: (ctx: InstallContext) => string;
}

const hex = (bytes: number): string => randomBytes(bytes).toString("hex");

// ework-web signs outgoing webhook POSTs with WORK_DAEMON_WEBHOOK_SECRET
// and ework-daemon verifies them with GITEA_WEBHOOK_SECRET. They MUST be
// the same value — pre-v0.2.6 each key had an independent hex(20) generator,
// so the two secrets never matched and every webhook was rejected with
// "invalid signature" on the daemon side.
//
// The closure-memoized `sharedWebhookSecret` returns the same value across
// both calls within a single install run, so first install is correct.
// Reconciliation for already-broken installs lives in install.ts (it reads
// both .env files and, if they differ, overwrites the daemon side from the
// web side — web is the source of truth because ework-web's DB has webhooks
// signed with whatever WORK_DAEMON_WEBHOOK_SECRET was at creation time).
let _sharedWebhookSecret: string | null = null;
function sharedWebhookSecret(): string {
  if (_sharedWebhookSecret === null) {
    _sharedWebhookSecret = hex(20);
  }
  return _sharedWebhookSecret;
}

export const WEB_ENV_KEYS: readonly EnvKeySpec[] = [
  { envVar: "WORK_PORT",                   file: "web", generate: (c) => String(c.workPort) },
  { envVar: "WORK_HOST",                   file: "web", generate: () => "0.0.0.0" },
  { envVar: "WORK_DATA_DIR",               file: "web", generate: (c) => c.paths.dataDir },
  { envVar: "WORK_TOKEN",                  file: "web", secret: true, generate: () => hex(20) },
  { envVar: "WORK_COOKIE_SECRET",          file: "web", secret: true, generate: () => hex(24) },
  { envVar: "WORK_OPERATOR_LOGIN",         file: "web", generate: (c) => c.operatorLogin },
  { envVar: "WORK_WRITES_ENABLED",         file: "web", generate: () => "true" },
  { envVar: "WORK_DB_PATH",                file: "web", generate: (c) => c.paths.webDbPath },
  { envVar: "WORK_ATTACHMENT_ROOT",        file: "web", generate: (c) => c.paths.webAttachmentRoot },
  { envVar: "WORK_FILE_ROOTS",             file: "web", generate: (c) => `/tmp,${c.paths.dataDir}` },
  // Without this, ework-web falls back to /tmp/ework-access.log which is
  // owned by whichever user touched it first. On shared boxes the runtime
  // user can't append → "EACCES: permission denied" on every request.
  { envVar: "WORK_ACCESS_LOG",             file: "web", generate: (c) => `${c.paths.runDir}/web-access.log` },
  { envVar: "WORK_DAEMON_BOT_LOGIN",       file: "web", generate: (c) => c.botName },
  { envVar: "WORK_DAEMON_WEBHOOK_URL",     file: "web", generate: (c) => `http://127.0.0.1:${c.routerPort}` },
  { envVar: "WORK_DAEMON_WEBHOOK_SECRET",  file: "web", secret: true, generate: sharedWebhookSecret },
] as const;

export const DAEMON_ENV_KEYS: readonly EnvKeySpec[] = [
  { envVar: "DAEMON_ENV",             file: "daemon", generate: () => "production" },
  { envVar: "DAEMON_PORT",            file: "daemon", generate: (c) => String(c.daemonPort) },
  { envVar: "DAEMON_HOST",            file: "daemon", generate: () => "0.0.0.0" },
  { envVar: "DAEMON_ENDPOINT",        file: "daemon", generate: (c) => `127.0.0.1:${c.daemonPort}` },
  { envVar: "DAEMON_DB_PATH",         file: "daemon", generate: (c) => c.paths.daemonDbPath },
  { envVar: "GITEA_URL",              file: "daemon", generate: (c) => `http://127.0.0.1:${c.workPort}` },
  // These tokens come from the bot bootstrap flow — empty placeholder here,
  // filled in by write_daemon_env after PAT is minted.
  { envVar: "GITEA_TOKEN",            file: "daemon", secret: true, generate: () => "" },
  { envVar: "GITEA_WEBHOOK_SECRET",   file: "daemon", secret: true, generate: sharedWebhookSecret },
  { envVar: "BOT_USERNAME",           file: "daemon", generate: (c) => c.botName },
  { envVar: "BOT_TOKEN",              file: "daemon", secret: true, generate: () => "" },
  { envVar: "OPENCODE_BINARY",        file: "daemon", generate: (c) => c.opencodeBin },
  { envVar: "OPENCODE_BASE_WORKDIR",  file: "daemon", generate: (c) => c.paths.opencodeWorkdir },
  { envVar: "WORK_RUNTIME",           file: "daemon", generate: () => "opencode" },
  { envVar: "WORK_PI_BINARY",         file: "daemon", generate: (c) => c.piBin },
  { envVar: "WORK_PI_PROVIDER",       file: "daemon", generate: (c) => c.piProvider },
  { envVar: "WORK_PI_DEFAULT_MODEL",  file: "daemon", generate: (c) => c.piModel },
] as const;

export const ROUTER_ENV_KEYS: readonly EnvKeySpec[] = [
  { envVar: "ROUTER_ENV",           file: "router", generate: () => "production" },
  { envVar: "ROUTER_PORT",          file: "router", generate: (c) => String(c.routerPort) },
  { envVar: "ROUTER_HOST",          file: "router", generate: () => "127.0.0.1" },
  { envVar: "ROUTER_STRATEGY",      file: "router", generate: () => "least-loaded" },
  { envVar: "ROUTER_FALLBACK_ENDPOINT", file: "router", generate: (c) => `http://127.0.0.1:${c.daemonPort}` },
  { envVar: "ROUTER_CONFIG_FILE",       file: "router", generate: (c) => `${c.paths.routerDataDir}/strategy.json` },
  { envVar: "WORK_DB_DRIVER",       file: "router", generate: () => "sqlite" },
  { envVar: "WORK_DB_PATH",         file: "router", generate: (c) => c.paths.daemonDbPath },
  { envVar: "WORK_DB_PREFIX",       file: "router", generate: () => "" },
  { envVar: "DAEMON_TABLE_PREFIX",  file: "router", generate: () => "" },
] as const;

export function keysForFile(file: EnvFile): readonly EnvKeySpec[] {
  if (file === "web") return WEB_ENV_KEYS;
  if (file === "router") return ROUTER_ENV_KEYS;
  return DAEMON_ENV_KEYS;
}

// Set of env vars that, if missing, would crash ework-web, ework-daemon, or
// ework-router at startup (Zod schema rejects). Used by env.ts forward-fill.
export const REQUIRED_KEYS: ReadonlySet<string> = new Set([
  ...WEB_ENV_KEYS.map((k) => k.envVar),
  ...DAEMON_ENV_KEYS.map((k) => k.envVar),
  ...ROUTER_ENV_KEYS.map((k) => k.envVar),
]);

// Keys whose value should be redacted in `config list` output.
export const SECRET_ENV_VARS: ReadonlySet<string> = new Set([
  ...WEB_ENV_KEYS.filter((k) => k.secret).map((k) => k.envVar),
  ...DAEMON_ENV_KEYS.filter((k) => k.secret).map((k) => k.envVar),
  ...ROUTER_ENV_KEYS.filter((k) => k.secret).map((k) => k.envVar),
]);
